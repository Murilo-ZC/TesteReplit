#include <stdio.h>

int main(){
  printf("Ola Mundo!\n");
  return 0;
}